package com.pacmanrevolution.characters;

class Pinky extends Ghost {

	public Pinky() {
		
	}

}
