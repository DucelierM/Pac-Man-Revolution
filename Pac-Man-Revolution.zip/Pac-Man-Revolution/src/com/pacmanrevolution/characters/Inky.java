package com.pacmanrevolution.characters;

class Inky extends Ghost{

	public Inky() {
		
	}

}
