package com.pacmanrevolution.game;

import java.awt.Button;

class Control {
	private  Button buttonLeft;
	private  Button buttonRight;
	private  Button buttonUp;
	private  Button buttonDown;
	private  Button buttonPausedMap;
	private  Button buttonSelect;
	private  Button buttonCancel;

	public Control() {
		
	}

	public boolean pushButtonLeft () {
		return false ;
	}

	public boolean pushButtonRignt () {
		return false ;
	}

	public boolean pushButtonUp () {
		return false ;
	}

	public boolean pushButtonDown () {
		return false ;
	}

	public boolean pushButtonPausedMap () {
		return false ;
	}

	public boolean pushButtonSelect () {
		return false ;
	}

	public boolean pushButtonCancel () {
		return false ;
	}

}
