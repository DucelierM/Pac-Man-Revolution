package com.pacmanrevolution.game;

abstract class Element {
	private Image elementImg = null;
	private Image elementImgIco = null;
	private int elementHeight = 0;
	private int elementLenth = 0;
	private int idElement;


	public Element(Image elementImg, Image elementImgIco, int elementHeight, int elementLenth, int idElement) {
		super();
		this.elementImg = elementImg;
		this.elementImgIco = elementImgIco;
		this.elementHeight = elementHeight;
		this.elementLenth = elementLenth;
		this.idElement = idElement;
	}

}


