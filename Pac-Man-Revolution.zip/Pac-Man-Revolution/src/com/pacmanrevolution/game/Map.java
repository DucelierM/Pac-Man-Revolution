package com.pacmanrevolution.game;


class Map extends Menu {
	protected mapSize[][] = {{700}{700}};
	protected Score mapScore ;
	protected frame mapTimer;
	protected int  mapComposition[399];

	public Map() {
		
	}

	public boolean mapCompleted () {
		
	}

	public boolean gameOver () {
		
	}

}
