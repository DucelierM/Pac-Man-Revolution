package com.pacmanrevolution.display;

abstract class Score {
	private int scoreFruit;
	private int scoreGhost;
	private  int scorePacGum;
	private  int scoreLife;
	private  boolean haveUsedContinues;
	private String namePlayer;

	public Score() {
		
	}

	public void showScore () {
		
	}

	public array String saveScore ( Score) {
		
	}

}