package com.pacmanrevolution.objets;

class PacGum extends Items {

	public PacGum() {
		
	}

}