package com.pacmanrevolution.objets;

import com.pacmanrevolution.game.Elements;
import com.pacmanrevolution.game.sound;

/* regroupe tous les objets et les murs */
abstract class Items extends Elements {
	private int score;
	private Sound soundEffect;

	public Items () {
		
	}

	public boolean isEaten () {
		
	}

}