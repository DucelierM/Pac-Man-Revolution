"# Pac-Man-Revolution" 
Ajout  des classes dans le code sans les methodes .
Quelques incohérence corrigés dans le projet (Score passe de "protected" en "private")

modification n°1