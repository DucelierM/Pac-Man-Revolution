package com.pacmanrevolution.objets;

class Wall extends Elements{

	public Wall() {
		
	}

}