package com.pacmanrevolution.objets;

class PacFruit extends Items {

	public PacFruit() {
		
	}
}
