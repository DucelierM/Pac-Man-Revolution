package com.pacmanrevolution.characters;

class Clyde extends Ghost {

	public Clyde() {
		
	}

}