package com.pacmanrevolution.display;

/* base de donnees ou sont regroupées les scores des joueurs (les 5 meilleurs)*/
class Result {
	private  String nomJoueur;
	private int resultFruit;
	private  int resultGhost;
	private boolean usedContinues;

	public Result() {
		
	}

}
